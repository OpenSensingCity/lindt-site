package lindt.dbpedialengthqueries;

import com.hp.hpl.jena.datatypes.TypeMapper;
import com.hp.hpl.jena.ontology.OntModelSpec;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.shared.impl.JenaParameters;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.jena.riot.RDFDataMgr;

public class Main {

    public static final String[] sizes = {"_12", "_25", "_50", "_100"};
    public static final int NB_ITER = 100;

    public static enum Type {

        QUDT("_qudt", "PREFIX qudt: <http://qudt.org/schema/qudt#>\n"
                + "PREFIX qudt-unit: <http://qudt.org/vocab/unit#>\n"
                + "SELECT ?x ?length (?factor*?length+?offset as ?metres) WHERE {\n"
                + "  ?x ?p [\n"
                + "    qudt:quantityValue [\n"
                + "      qudt:numericValue ?length ;\n"
                + "      qudt:unit ?unit ] ] .\n"
                + "  ?unit qudt:conversionFactor ?factor ;\n"
                + "    qudt:conversionOffset ?offset .\n"
                + "    FILTER( ?factor*?length+?offset < 5 )\n"
                + "}\n"
                + "ORDER BY DESC (?metres)\n"
                + "LIMIT 100"),
        NORMAL("", "SELECT ?x ?length ?metres WHERE {\n"
                + "VALUES (?factor ?unit)\n"
                + "{ (0.001 <http://dbpedia.org/datatype/millimetre>)\n"
                + "  (0.01 <http://dbpedia.org/datatype/centimetre>)\n"
                + "  (1 <http://dbpedia.org/datatype/metre>)\n"
                + "  (1000 <http://dbpedia.org/datatype/kilometre>)\n"
                + "}\n"
                + "  ?x ?p ?length .\n"
                + "  BIND (?factor*<http://www.w3.org/2001/XMLSchema#decimal>(?length) as ?metres)\n"
                + "  FILTER(datatype(?length)=?unit) \n"
                + "  FILTER( ?metres<5 ) \n"
                + "\n"
                + "\n"
                + "} \n"
                + "ORDER BY DESC ( ?metres )\n"
                + "LIMIT 100"),
        CUSTOM("_custom", "SELECT ?x ?y WHERE {\n"
                + "  ?x ?p ?y .\n"
                + "  FILTER(datatype(?y)= <http://w3id.org/lindt/custom_datatypes#length> )\n"
                + "  FILTER( ?y < \"5m\"^^<http://w3id.org/lindt/custom_datatypes#length> )\n"
                + "} \n"
                + "ORDER BY DESC(?y)\n"
                + "LIMIT 100", true, true),
        CUSTOM2("_custom", "SELECT ?x ?y WHERE {\n"
                + "  ?x ?p ?y .\n"
                + "  FILTER(datatype(?y)= <http://w3id.org/lindt/custom_datatypes#length> )\n"
                + "  FILTER( ?y < \"5m\"^^<http://w3id.org/lindt/custom_datatypes#length> )\n"
                + "} \n"
                + "ORDER BY DESC(?y)\n"
                + "LIMIT 100", true, false),
        CUSTOM_ANCHOR("_custom", "SELECT ?x ?y WHERE {\n"
                + "  ?x <http://dbpedia.org/ontology/Person/height> ?y .\n"
                + "} \n"
                + "ORDER BY DESC(?y)\n"
                + "LIMIT 100", true, true),
        QUDT_ANCHOR("_qudt", "PREFIX qudt: <http://qudt.org/schema/qudt#>\n"
                + "PREFIX qudt-unit: <http://qudt.org/vocab/unit#>\n"
                + "SELECT ?x ?length (?factor*?length+?offset as ?metres) WHERE {\n"
                + "  ?x <http://dbpedia.org/ontology/Person/height> [\n"
                + "    qudt:quantityValue [\n"
                + "      qudt:numericValue ?length ;\n"
                + "      qudt:unit ?unit ] ] .\n"
                + "  ?unit qudt:conversionFactor ?factor ;\n"
                + "    qudt:conversionOffset ?offset .\n"
                + "}\n"
                + "ORDER BY DESC (?metres)\n"
                + "LIMIT 100");

        private final String addition;
        private final String query;
        private final boolean useCustom;
        private final boolean hotstart;

        private Type(String addition, String query) {
            this(addition, query, false, false);
        }

        private Type(String addition, String query, boolean useCustom, boolean hotstart) {
            this.addition = addition;
            this.query = query;
            this.useCustom = useCustom;
            this.hotstart = hotstart;
        }

    }

    public static void main(String[] args) throws FileNotFoundException, IOException {
        try (FileWriter fo = new FileWriter(new File("results.txt"))) {
            for (Type type : Type.values()) {
                JenaParameters.enableDiscoveryOfCustomDatatypes = type.useCustom;
                System.out.println(type);
                for (String size : sizes) {
                    System.out.println(size);
                    test(type, size, fo);
                }
            }
        }
    }

    public static void test(Type type, String size, FileWriter fo) throws IOException {
        TypeMapper.reset();
        String filename = "dbpedia/specific_mappingbased_properties_en_lengths" + type.addition + size + ".ttl";
        System.out.println(filename);
        fo.write("\n" + type.name() + "\n");
        fo.write(size + "\n");
        if (JenaParameters.enableDiscoveryOfCustomDatatypes && type.hotstart) {
            long t1 = System.currentTimeMillis();
            TypeMapper.getInstance().getSafeTypeByName("http://w3id.org/lindt/custom_datatypes#length");
            long t2 = System.currentTimeMillis();
            fo.write("loaded type in " + (t2 - t1) + "ms\n");
        }
        double[] loadTimes = new double[NB_ITER];
        double[] queryTimes = new double[NB_ITER];
        for (int i = 0; i < NB_ITER; i++) {
            if (!type.hotstart) {
                TypeMapper.reset();
            }
            Model m = ModelFactory.createOntologyModel(OntModelSpec.RDFS_MEM);
            long t1 = System.currentTimeMillis();
            RDFDataMgr.read(m, filename);
            long t2 = System.currentTimeMillis();
            loadTimes[i] = t2 - t1;

            String queryString = type.query;
            Query query = QueryFactory.create(queryString);
            long t3 = System.currentTimeMillis();
            try (QueryExecution qexec = QueryExecutionFactory.create(query, m)) {
                ResultSet results = qexec.execSelect();
                for (; results.hasNext();) {
                    QuerySolution sol = results.nextSolution();
//                    System.out.println("sol");
//                    Iterator<String> varnames = sol.varNames();
//                    while(varnames.hasNext()) {
//                        String var = varnames.next();
//                        System.out.println("name "+var+" -- "+sol.get(var));
//                    }
                }
            }
            long t4 = System.currentTimeMillis();
            queryTimes[i] = t4 - t3;
            m.close();
        }
        writeResults("load", loadTimes, fo);
        writeResults("query", queryTimes, fo);
    }

    public static void writeResults(String title, double[] data, FileWriter fo) throws IOException {

        Statistics stats = new Statistics(data);

        fo.write(Math.round(stats.getMean()) + " ( +- " + Math.round(stats.getStdDev()) + ")\n");
        System.out.println(Math.round(stats.getMean()) + " ( +- " + Math.round(stats.getStdDev()) + ")");
    }

    static class Result {

        final long load;
        final long query;

        public Result(Long load, Long query) {
            this.load = load;
            this.query = query;
        }

    }

    static class Statistics {

        double[] data;
        double size;

        public Statistics(double[] data) {
            this.data = data;
            size = data.length;
        }

        double getMean() {
            double sum = 0.0;
            for (double a : data) {
                sum += a;
            }
            return sum / size;
        }

        double getVariance() {
            double mean = getMean();
            double temp = 0;
            for (double a : data) {
                temp += (mean - a) * (mean - a);
            }
            return temp / size;
        }

        double getStdDev() {
            return Math.sqrt(getVariance());
        }

    }

}
